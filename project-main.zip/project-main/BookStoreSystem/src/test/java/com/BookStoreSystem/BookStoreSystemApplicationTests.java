package com.BookStoreSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
